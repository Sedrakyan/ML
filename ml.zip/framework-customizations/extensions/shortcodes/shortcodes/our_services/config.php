<?php
if( !defined('FW')) {die('Forbidden');}

$cfg=array(
    'page_builder' => array(
        'title' => 'Our Services',
        'tab' => __( 'Custom Elements', 'fw')
    )
)
?>