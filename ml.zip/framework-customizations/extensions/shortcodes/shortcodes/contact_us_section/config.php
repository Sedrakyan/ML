<?php
if( !defined('FW')) {die('Forbidden');}

$cfg=array(
    'page_builder' => array(
        'title' => 'Contact Us',
        'tab' => __( 'Custom Elements', 'fw')
    )
)
?>