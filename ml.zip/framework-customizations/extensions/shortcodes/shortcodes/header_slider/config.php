<?php
if( !defined('FW')) {die('Forbidden');}

$cfg=array(
    'page_builder' => array(
        'title' => 'Header Slide',
        'tab' => __( 'Custom Elements', 'fw')
    )
)
?>