<?php
if( !defined('FW')) {die('Forbidden');}

$cfg=array(
    'page_builder' => array(
        'title' => 'Pricing Plan',
        'tab' => __( 'Custom Elements', 'fw')
    )
)
?>