<?php
if( !defined('FW')) {die('Forbidden');}

$cfg=array(
    'page_builder' => array(
        'title' => 'Discount',
        'tab' => __( 'Custom Elements', 'fw')
    )
)
?>