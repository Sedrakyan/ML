<?php
if( !defined('FW')) {die('Forbidden');}

$cfg=array(
    'page_builder' => array(
        'title' => 'Testimonials',
        'tab' => __( 'Custom Elements', 'fw')
    )
)
?>