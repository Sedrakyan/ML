<?php
if( !defined('FW')) {die('Forbidden');}

$cfg=array(
    'page_builder' => array(
        'title' => 'Client',
        'tab' => __( 'Custom Elements', 'fw')
    )
)
?>