<?php
if( !defined('FW')) {die('Forbidden');}

$cfg=array(
    'page_builder' => array(
        'title' => 'Our Blog',
        'tab' => __( 'Custom Elements', 'fw')
    )
)
?>