<?php
if( !defined('FW')) {die('Forbidden');}

$cfg=array(
    'page_builder' => array(
        'title' => 'Achievement',
        'tab' => __( 'Custom Elements', 'fw')
    )
)
?>